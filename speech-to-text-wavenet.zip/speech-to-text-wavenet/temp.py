import sugartensor as tf

# set log level to debug
tf.sg_verbosity(10)

# MNIST input tensor ( with QueueRunner )
data = tf.sg_data.Mnist(batch_size=32)

# inputs
x = data.train.image
y = data.train.label

# create training graph
logit = (x.sg_flatten()
         .sg_dense(dim=400, act='relu')
         .sg_dense(dim=200, act='relu')
         .sg_dense(dim=10))

# cross entropy loss with logit ( for training set )
loss = logit.sg_ce(target=y)

grad = tf.gradients(loss, [t for t in tf.trainable_variables()])

# evaluate tensor list with queue runner
res = []
with tf.Session(config=tf.ConfigProto(allow_soft_placement=True)) as sess:
    tf.sg_init(sess)
    with tf.sg_queue_context():
        for _ in range(30):
            res.append(sess.run(grad)[0])

import numpy as np
a = np.asarray(res)

print(len(a))



# import numpy as np
# import librosa
# import scikits.audiolab
# import time
#
#
# # f = 'asset/data//TEDLIUM_release2/dev/sph/AlGore_2009.sph.wav'
# # f = 'asset/data/VCTK-Corpus/wav48/p376/p376_295.wav'
# f = 'asset/data/LibriSpeech/train-clean-360/986/129388/986-129388-0001.flac'
#
# t0 = time.time()
#
# wave, sr = librosa.core.load(f, mono=True, sr=None, offset=0., duration=None)
# if sr == 48000:
#     wave = wave[::3]
#
# # random volume
# wave *= np.exp(np.random.uniform(-1, 1))
#
# # add noise ( SNR : 10 % )
# n = np.random.uniform(-1, 1, wave.shape) * np.exp(np.random.uniform(-1, 1)) * 0.1
# wave += n
#
# t1 = time.time()
#
# mfcc = librosa.feature.mfcc(wave, sr=16000)
#
# t2 = time.time()
#
# print(wave.shape, mfcc.shape, sr)
# print('t1 = %f, t2 = %f' % (t1 - t0, t2 - t1))
# scikits.audiolab.play(wave, fs=16000)


# find -type f -name '*.sph' | awk '{printf "sox -t sph %s -b 16 -t wav %s\n", $0, $0".wav" }' | bash


